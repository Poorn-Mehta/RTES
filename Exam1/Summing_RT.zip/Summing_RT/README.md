To execute the program follow these instructions

please note that this single code is able to execute using both - FIFO as well as OTHER scheduler

execute make

an executable named Sum should have been created

before executing, get root access and execute the RTES_Config script

then, for FIFO - run ./Sum FIFO

or, for OTHER - run ./Sum

To analyze outputs, simply copy the last line in code printf output, and paste in a separate terminal

